class Rotas {
  static const HOME = '/';
  static const PRODUTOS = "/tela_produtos";
  static const CATEGORIA = "/categoria";
  static const TESTE ='/categoria_produto';
  static const Formulario= "/formulario";
  static const Formulariocard= "/formulariocard";
  static const CATEGORIAPRODUTO = "/categoria/:id";
}